<template>
  <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" class="contact-icon">
    <path d="M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"/>
  </svg>
</template>

<script setup>
</script>

<style scoped>
.contact-icon {
  width: 2rem;
  height: 2rem;
  fill: var(--accent);
}
</style>
